package testCases;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import objectRepository.objectRepository;
import reusableFunctions.ReusableFunctions;

public class CaseStudy_Suite extends ReusableFunctions {

	ReusableFunctions Reusables = new ReusableFunctions();
	public objectRepository ObjectRep;

	@BeforeTest

	public void LoadTestDataObjectMap() throws IOException {
		ObjectRep = new objectRepository(path + "\\Assets\\OR.properties");

	}

	@BeforeTest
	public void initialize() {
		Reusables.LaunchBrowser("Chrome", "C://Users//rmuraleedharan//Desktop//index.html");

	}

	@Test(description = "TC1 Verifies Email Adress and Password Fields")
	public void TC1_Assert_Login_Page() {

		Reusables.verifyexist(ObjectRep.getbjectLocator("EmailAddress"), "Email Address Text Box");
		Reusables.verifyexist(ObjectRep.getbjectLocator("Password"), "Password Text Box");
		Reusables.verifyexist(ObjectRep.getbjectLocator("SignIn"), "Sign In Button");
		Reusables.Type(ObjectRep.getbjectLocator("EmailAddress"), "Test");
		Reusables.Type(ObjectRep.getbjectLocator("Password"), "1234");
	}

	@Test(description = "TC2 Verifies values in the listgroup")
	public void TC2_Assert_List_Values()

	{

		WebElement List_Group = driver.findElement(ObjectRep.getbjectLocator("List_Group"));
		List<WebElement> List_Elements = List_Group.findElements(ObjectRep.getbjectLocator("List_Items"));
		int count = List_Elements.size();
		if (count == 3) {
			System.out.println("Pass: There are three values in the List Group");
		} else {
			System.out.println("Fail: List Group does not have three items");
		}

		String List_Value2_Name = List_Elements.get(1).getText();
		if (List_Value2_Name.contains("List Item 2")) {
			System.out.println("Pass: Second Value is set to List Item 2 ");
		} else {
			System.out.println("Fail: Second Value is NOT set to List Item 2 ");
		}
		String List_Item2_Badge = driver.findElement(ObjectRep.getbjectLocator("List_Items_Badge")).getText();
		if (List_Item2_Badge.equals("6")) {
			System.out.println("Pass: Badge of Second List Value is set to 6 ");
		} else {
			System.out.println("Fail: Badge of Second List Value is NOT set to 6");
		}
	}

	@Test(description = "TC3 Verifies values test 3 div options")
	public void TC3_Assert_Select_Options() throws InterruptedException {

		String Default_Option = driver.findElement(ObjectRep.getbjectLocator("Option_Button")).getText();
		if (Default_Option.equals("Option 1")) {
			System.out.println("Pass: Option 1 is selected by default ");
		} else {
			System.out.println("Fail: Option 1 is not selected by default");
		}
		driver.findElement(ObjectRep.getbjectLocator("Option_Button")).click();
		List<WebElement> OptionItems = driver.findElements(ObjectRep.getbjectLocator("Option_Items"));
		for (int i = 0; i < OptionItems.size(); i++) {
			String Option_value = OptionItems.get(i).getText();
			if (Option_value.equals("Option 3"))
				OptionItems.get(i).click();
		}

		String Selected_Option = driver.findElement(ObjectRep.getbjectLocator("Option_Button")).getText();
		if (Selected_Option.equals("Option 3")) {
			System.out.println("Pass: Option 3 is selected");
		} else {
			System.out.println("Fail: Option 3 is not selected");
		}

	}

	@Test(description = "TC4 Verifies buttons test 4 div")
	public void TC4_Assert_Buttons() {

		if (driver.findElement(ObjectRep.getbjectLocator("Button_Enabled")).isEnabled()) {
			System.out.println("Pass-First Button is Enabled");

		} else {
			System.out.println("Fail- First Button is not Enabled");
		}
		if (driver.findElement(ObjectRep.getbjectLocator("Button_Disabled")).isEnabled()) {
			System.out.println("Fail-Second Button is Enabled");

		} else {
			System.out.println("Pass- Second Button is not Enabled");
		}

	}

	@Test(description = "TC5 Verifies Button in test 5 div")
	public void TC5_Assert_Button_Visibility() {

		WebDriverWait wait = new WebDriverWait(driver, 20);
		wait.until(ExpectedConditions.elementToBeClickable(ObjectRep.getbjectLocator("Button_Option_5")));
		driver.findElement(ObjectRep.getbjectLocator("Button_Option_5")).click();
		String Alert_Message = driver.findElement(ObjectRep.getbjectLocator("Alert_Test5")).getText();
		if (Alert_Message.equals("You clicked a button!")) {
			System.out.println("Pass Alert Message is displayed");

		} else {
			System.out.println("Fail Alert Message is not displayed");

		}
		Boolean button_visibility = driver.findElement(ObjectRep.getbjectLocator("Button_Option_5")).isEnabled();
		if ((button_visibility) == false) {
			System.out.println("Pass :Button is disabled");

		} else {
			System.out.println("Fail :Button is Not disabled");
		}

	}

	@Test(description = "TC6 Verifies CellValue in table")
	public void TC6_Assert_Table() {

		String Cellvalue = Reusables.getTableDetails(ObjectRep.getbjectLocator("Table_Name"), 2, 2);
		if (Cellvalue.equals("Ventosanzap")) {
			System.out.println("Pass- Value in the cell is correct");
		} else {
			System.out.println("Pass- Value in the cell is not correct");
		}

	}

	@AfterTest
	public void teardown() {
		driver.close();

	}

}
