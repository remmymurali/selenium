package objectRepository;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
 
import org.openqa.selenium.By;

public class objectRepository {
	public FileInputStream stream;
	public String File;
	public Properties propertyfile = new Properties();
	public objectRepository(String fileName) throws IOException
	{
		this.File = fileName;
		stream = new FileInputStream(File);
		propertyfile.load(stream);
		
	}

	public By getbjectLocator(String locatorName)
	{
		String locatorProperty = propertyfile.getProperty(locatorName);
		String locatorType = locatorProperty.split(":")[0];
		String locatorValue = locatorProperty.split(":")[1];
 
		By locator = null;
		switch(locatorType.toUpperCase())
		{
		case "ID":
			locator = By.id(locatorValue);
			break;
		case "NAME":
			locator = By.name(locatorValue);
			break;
		case "CSSSELECTOR":
			locator = By.cssSelector(locatorValue);
			break;
		case "LINKTEXT":
			locator = By.linkText(locatorValue);
			break;
		case "PARTIALLINKTEXT":
			locator = By.partialLinkText(locatorValue);
			break;
		case "TAGNAME":
			locator = By.tagName(locatorValue);
			break;
		case "XPATH":
			locator = By.xpath(locatorValue);
			break;
		}
		return locator;
	}

}
