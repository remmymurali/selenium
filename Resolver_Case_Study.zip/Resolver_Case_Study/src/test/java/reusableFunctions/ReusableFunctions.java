package reusableFunctions;

import java.io.IOException;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import objectRepository.objectRepository;

public class ReusableFunctions {

	public static String path = System.getProperty("user.dir");
	public static WebDriver driver;

	public void LaunchBrowser(String Browser, String URL) {

		switch ((Browser.toUpperCase())) {

		case "IE": {

			System.setProperty("webdriver.ie.driver", path + "\\Assets\\IEDriverServer.exe");
			driver = new InternetExplorerDriver();
			driver.get(URL);
			driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			driver.manage().window().maximize();
		}

		case "CHROME": {
			System.setProperty("webdriver.chrome.driver", path + "\\Assets\\chromedriver.exe");
			driver = new ChromeDriver();
			driver.get(URL);
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.manage().window().maximize();
		}
		}

	}

	public void verifyexist(By locator, String ObjectName) {
		try {
			WebElement element = driver.findElement(locator);
			Boolean exist_element = element.isDisplayed();
			if (exist_element == true) {
				System.out.println("Pass:" + ObjectName + " Exists");
			} else {
				System.out.println("Pass:" + ObjectName + " does not exist");

			}

		} catch (NoSuchElementException e) {
			System.err.format("No such Object exist" + e);

		}
	}

	public void Type(By locatorname, String text) {
		try {

			WebElement element = driver.findElement(locatorname);
			element.sendKeys(text);
		} catch (NoSuchElementException e) {
			System.err.format("No Element Found to enter text" + e);
		}
	}

	public String getTableDetails(By Locator, int row, int column) {

		WebElement element = driver.findElement(Locator);
		List<WebElement> rows = element.findElements(By.tagName("tr"));

		List<WebElement> columns = rows.get(row + 1).findElements(By.tagName("td"));

		return (columns.get(column).getText());

	}

}
